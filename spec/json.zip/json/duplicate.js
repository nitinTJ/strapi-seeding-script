import strapi_variant from "./strapiVariant.json" assert { type: "json" };
import bike_variant from ".//bikeVariant.json" assert { type: "json" };
import b from "./strapi_brand.json" assert { type: "json" };
import fs from "fs";

function fetchData(url, method, requestData) {
  const options = {
    method: method,
    headers: {
      "Content-Type": "application/json",
    },
  };

  if (requestData) {
    options.body = requestData;
  }

  return fetch(url, options)
    .then((response) => {
      if (response.ok) {
        return response.json();
      } else {
        throw new Error(`Error: ${response.status} - ${response.statusText}`);
      }
    })
    .catch((error) => {
      console.error(error);
    });
}
const data = strapi_variant
  .map((item) => {
    if (!item.attributes.images.data) {
      // const images = item.attributes.images.data.map((i) => {
      //   return { id: i.id };
      // });
      // const body = {
      //   data: {
      //     images: images.reverse(),
      //   },
      // };

      return item;
      // fetchData(
      //   `https://bikes-cms.tractorjunction.com/api/variants/${item.id}`,
      //   "PUT",
      //   JSON.stringify(body)
      // );
    }
    // const body = {
    //   data: {
    //     min_price: v[0].min_price,
    //     max_price: v[0].max_price,
    //   },
    // };
  })
  .filter(Boolean);

fs.writeFile("users.json", JSON.stringify(data), (err) => {
  // Checking for errors
  if (err) throw err;
  console.log("Done writing"); // Success
});

console.log(data.length);

function updateDate() {
  Promise.all(data)
    .then((data) => {
      console.log(data);
    })
    .catch((error) => {
      // Handle any errors that occurred during the API calls
      console.error(error);
    });
}

updateDate();
